# 3phase_integrated
3-phase motor controller with integrated position sensor
Firmware here:
https://os.mbed.com/users/benkatz/code/Hobbyking_Cheetah_Compact/

Firmware for new versions with DRV8323:
https://os.mbed.com/users/benkatz/code/Hobbyking_Cheetah_Compact_DRV8323/
